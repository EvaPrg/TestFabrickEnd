package it.fabrick.appFabrick.Repository;

public interface BonificoRepository {
}
